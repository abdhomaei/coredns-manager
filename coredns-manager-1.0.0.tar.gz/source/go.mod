module coredns-manager

go 1.25.12
