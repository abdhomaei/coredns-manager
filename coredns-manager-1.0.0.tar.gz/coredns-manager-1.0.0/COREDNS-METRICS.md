# Real CoreDNS Prometheus graphs

Enable the CoreDNS Prometheus plugin:

    . {
        prometheus 127.0.0.1:9153
        ...
    }

Test:

    fetch -qo- http://127.0.0.1:9153/metrics

The Go manager scrapes that endpoint directly. Set `COREDNS_PROMETHEUS_URL` to use another address.

The dashboard calculates QPS from successive `coredns_dns_requests_total` counter values and aggregates query types, zones and response codes. It also reads request-duration and cache metrics when present.
